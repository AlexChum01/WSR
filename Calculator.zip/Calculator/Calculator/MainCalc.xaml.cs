﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Логика взаимодействия для MainCalc.xaml
    /// </summary>
    public partial class MainCalc : Window
    {
        public MainCalc()
        {
            InitializeComponent();
            foreach (UIElement el in MainRoot.Children) 
            {
                if (el is System.Windows.Controls.Button) 
                {
                    ((System.Windows.Controls.Button)el).Click += Button_CLick;                }
            }
        }

        private void Button_CLick(object sender, RoutedEventArgs e)
        {
            string str = (string)((System.Windows.Controls.Button)e.OriginalSource).Content;
            if (str == "C")
            
                textC.Text = "";
            else if (str=="=")
            {
                string value = new DataTable().Compute(textC.Text, null).ToString();
                textC.Text = value;

            }
            else 
            textC.Text += str;
        }

        private void Next(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void Close(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Закрыть приложение?", "Закрытие", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if(result.ToString()=="Yes")
           {
                this.Close();
            }
            }
    }
}
